module.exports = {
    coveragePathIgnorePatterns: ["/node_modules/", "/vendor/"]
}