/*!
 * AllOrigins
 */

const app = require('./app.js')
const port = process.env.PORT || 8118

console.log(`Starting Bigin wpx v${global.AO_VERSION}`)
app.listen(port, () => console.log('Listening on', port))
