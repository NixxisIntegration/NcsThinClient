function handleSearchModePreview(index) {
  let tempArray = document
    .getElementById("search-mode")
    .querySelector(".modal-content")
    .querySelector("li")
    .querySelector(".accord-detail")
    .querySelectorAll("p");
  const isCheck = document
    .getElementById(index)
    .classList.contains("detail-search-active");
  const tempArrButton = document
    .getElementById("search-mode")
    .querySelector(".modal-footer")
    .querySelectorAll("button");
  for (let i = 0; i < tempArrButton.length; i++) {
    tempArrButton[i].disabled = false;
  }
  if (isCheck) {
    return;
  } else {
    let itemCurrentActive = [...tempArray].find(
      (item) => item.classList.contains("detail-search-active") === true
    );
    if (itemCurrentActive) {
      itemCurrentActive.classList.remove("detail-search-active");
      document.getElementById(index).classList.add("detail-search-active");
    } else {
      document.getElementById(index).classList.add("detail-search-active");
    }
  }
}
function handleChangePage(argu_id) {
  let tempArray = document
    .getElementById("search-modal-header")
    .querySelectorAll("div");
  const isCheck = document
    .getElementById(argu_id)
    .classList.contains("search-tab-active");
  if (isCheck) {
    return;
  } else {
    let itemCurrentActive = [...tempArray].find(
      (item) => item.classList.contains("search-tab-active") === true
    );
    if (itemCurrentActive) {
      itemCurrentActive.classList.remove("search-tab-active");
      document.getElementById(argu_id).classList.add("search-tab-active");
    } else {
      document.getElementById(argu_id).classList.add("search-tab-active");
    }
  }
}

// check func again
const handlePreviewSearch = (active) => {
  document.getElementById("search-mode").classList.remove("active");
  const btn_search_mode = document.querySelector(
    '[data-target="#search-mode"]'
  );
  const btn_search_mode_mobile = document.querySelector(
    '[data-keep-target="#search-mode-mobile"]'
  );
  btn_search_mode.classList.remove("active");
  btn_search_mode_mobile.classList.remove("active");
  const contentObject = document.getElementById("content-embed");
  const contentSearchMode = document.getElementById("content-searchMode");

  const statusBox = document.querySelector(".status-box-desktop");
  const statusBoxMobile = document.querySelector("#status-wrap-mobile");
  let node_search_box = document.createElement("div");
  let node_search_box1 = document.createElement("div");

  const div_search_box = `
    <div>
      <img
        src="./assets/icons/Agent_MediaType_Outbound_36.png"
        alt="icon"
      />
    </div>
    <div id="status-box">
      <div class="row d-flex cardBoxRow">
        <div><strong>Search lab &nbsp;</strong></div>
        <div><span>00:00:00</span></div>
      </div>
      <div class="row d-flex cardBoxRow">
        <div><span>From:&nbsp;</span></div>
        <div><span>00:00:00</span></div>
      </div>
      <div class="row d-flex cardBoxRow">
        <div><span>To:&nbsp;</span></div>
        <div><span>00:00:00</span></div>
      </div>
      <div class="row d-flex cardBoxRow">
        <div><span>State:&nbsp;</span></div>
        <div><span>Preview</span></div>
      </div>
      <div class="row d-flex cardBoxRow">
        <div><span>Customer:&nbsp;</span></div>
        <!-- <div><span>Preview</span></div> -->
      </div>
    </div>
`;
  node_search_box.innerHTML = div_search_box;
  node_search_box1.innerHTML = div_search_box;

  let item_Active = document.querySelectorAll(".cardBoxLayer.active");

  if (active === "displaySearchMode") {
    [...item_Active].forEach((item) => item.classList.remove("active"));
    node_search_box.className = "status cardBoxLayer active";
    node_search_box1.className = "status cardBoxLayer active";
    statusBox.appendChild(node_search_box);
    statusBoxMobile.appendChild(node_search_box1);
    contentObject.classList.remove("active");
    contentSearchMode.classList.add("active");
    showOverLayModal(false);
    btn_search_mode.disabled = true;
    btn_search_mode_mobile.disabled = true;

    // CHECK AUTO Active and action
    const doc = document.querySelectorAll(".cardBoxLayer");
    if (doc.length >= 3) {
      document.querySelector("#resetBtn-3").style.display = "flex";
    }
    doc.forEach(function (item) {
      item.addEventListener("click", function (e) {
        e.preventDefault();
        clearStyle();
        item.classList.add("active");
        window.dc().handleHeightChange(false);
        if (item.classList.contains("active")) {
          item.children[0].children[0].style.width = "60px";
        }

        window.dc().styleRadiusDefault();
      });
    });
    function clearStyle() {
      buttonWithActive = document.querySelector(".cardBoxLayer.active");
      buttonWithActive.classList.remove("active");
    }

    window.dc().handleHeightChange(false);
    window.dc().renderElm("bottom-middle-right");
    LoadContacts();
    // end
    return;
  }
  if (active === "closeSearchMode") {
    const statusSearchMode = document.getElementById("status-searchMode");
    if (statusSearchMode) {
      statusSearchMode.remove();
    }
    contentObject.classList.add("active");
    contentSearchMode.classList.remove("active");
    btn_search_mode.disabled = false;
    btn_search_mode_mobile.disabled = false;
    showOverLayModal(false);
    handleChangeDisabled();
  }
};
const showOverLayModal = (argu) => {
  argu === true
    ? (document.getElementById("overlay-modal").style.zIndex = 101)
    : (document.getElementById("overlay-modal").style.zIndex = -1);
};
const handleChangeDisabled = () => {
  let tempArray = document.getElementById("search-mode");
  let btn_footer = tempArray
    .querySelector(".modal-footer")
    .querySelectorAll("button");
  let content_searchMode = tempArray.querySelector(".modal-content");
  for (let i = 0; i < btn_footer.length; i++) {
    tempArray.querySelector(".modal-footer").querySelector("[data-close]") ===
    btn_footer[i]
      ? btn_footer[i]
      : (btn_footer[i].disabled = true);
  }
  content_searchMode.querySelector(".accord-detail").style.display = "none";
  content_searchMode.querySelector(".acclink").classList.remove("active");
  if (content_searchMode.querySelector(".detail-search-active")) {
    content_searchMode
      .querySelector(".detail-search-active")
      .classList.remove("detail-search-active");
  }
};
