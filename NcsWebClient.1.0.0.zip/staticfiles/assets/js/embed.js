const hash = window.location.hash;

function showMessage(message, subtitle, image) {
  $("message_h1").textContent = message;
  $("message_p").textContent = subtitle;
  $("imgEmdedAgentStateGIF").setAttribute("src", image);
  if (multiLang && multiLang.onload) multiLang.onload();
}

if (["#break", ""].includes(hash)) {
  showMessage(
    "You are currently on a break",
    "Click on ready to start working",
    "./assets/animations/Agent_pause.gif"
  );
} else if (hash === "#ready") {
  showMessage(
    "You are waiting for contact",
    "",
    "./assets/animations/Agent_waiting.gif"
  );
}
