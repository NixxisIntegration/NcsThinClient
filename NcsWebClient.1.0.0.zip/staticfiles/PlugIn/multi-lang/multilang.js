// MultiLang - BdR 2016
// JavaScript object to handle multilanguage, load phrases from JSON etc.
const LANG_CODE = {
  en: "en",
  fr: "fr",
};

async function MultiLang(url, lang, onload) {
  // variables
  let phrases = {};

  // language code from parameter or if null then default to browser language preference
  // Keep only first two characters, for example 'en-US' -> 'en', or 'nl-NL' -> 'nl' etc.
  let selectedLanguage = (
    lang ||
    navigator.language ||
    navigator.userLanguage
  ).substring(0, 2);

  // load json from url
  if (typeof url !== "undefined") {
    phrases = await fetch(url).then((r) => r.json());
  }

  const setLanguage = (langcode) => {
    // check if language code <langcode> does not exist in available translations in json file
    // For example, available translated texts in json are 'en' and 'fr', but client language is 'es'
    if (!phrases.hasOwnProperty(langcode)) {
      // doesn't exist so default to the first available language, i.e. the top-most language in json file

      // NOTE: the order of properties in a JSON object are not *guaranteed* to be the same as loading time,
      // however in practice all browsers do return them in order
      for (var key in phrases) {
        if (phrases.hasOwnProperty(key)) {
          langcode = key; // take the first language code
          break;
        }
      }
    }

    // set as selected language code
    selectedLanguage = langcode;
  };

  const get = function (key, arr = []) {
    // get key phrase
    var str = key;

    // check if any languages were loaded
    if (phrases[selectedLanguage])
      str = phrases[selectedLanguage][key.toLowerCase()];

    if (arr.length && str) {
      const regex = /{[0-9]}/
      if (regex.test(str)) {
        arr.forEach((arg, i) => {
          str = str.replace("{" + i + "}", get(arg));
        });
      } else {
        str = str + arr.join('');
      }
    }

    // if key does not exist, return the literal key
    str = str || key;
    return str;
  };

  return { phrases, selectedLanguage, onload, setLanguage, get };
}
