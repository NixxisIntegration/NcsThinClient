var CrResource = 
{
	
}
