﻿const showModal = (name) => {
    let modal;
    if (name === "first") {
        modal = document.getElementById("AgentToolStrip");
        document.getElementById("VoiceToolStrip").style.display = "none";
    } else {
        modal = document.getElementById("VoiceToolStrip");
        document.getElementById("AgentToolStrip").style.display = "none";
    }
    document.getElementById("exit-modal").style.display = "block";
    document.getElementById("voiceStatusToolStrip").style.display = "none";
    document.getElementById("bottom-right").style.display = "none";
    modal.style.display = "grid";
    modal.style.width = "100%";
    modal.style.resize = "none";
    modal.style.borderRight = "none";
}


const exitModal = () => {
    const bottomLeft = document.getElementById("AgentToolStrip");
    const bottomMiddleLeft = document.getElementById("VoiceToolStrip");

    for (let element of [bottomLeft, bottomMiddleLeft]) {
        element.style.display = "none";
        element.style.width = "25%";
        element.style.resize = "horizontal";
        element.style.borderRight = "2px solid silver";
    }

    document.getElementById("exit-modal").style.display = "none";
    document.getElementById("voiceStatusToolStrip").style.display = "grid";
    document.getElementById("bottom-right").style.display = "grid";
}


document.addEventListener("resize", (event) => { });
